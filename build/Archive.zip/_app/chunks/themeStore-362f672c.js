import{C as r}from"./vendor-4c629592.js";const a=r("gray"),o=r("large");export{o as h,a as t};
